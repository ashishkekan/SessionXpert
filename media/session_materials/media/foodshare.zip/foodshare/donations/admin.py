from django.contrib import admin

from .models import Claim, Donation


@admin.register(Donation)
class DonationAdmin(admin.ModelAdmin):
    list_display = ('title', 'donor', 'status', 'created_at', 'expiry')
    list_filter = ('status', 'created_at')

@admin.register(Claim)
class ClaimAdmin(admin.ModelAdmin):
    list_display = ('donation', 'claimant', 'volunteer', 'claimed_at')