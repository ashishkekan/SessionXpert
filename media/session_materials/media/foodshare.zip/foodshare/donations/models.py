from django.db import models

from core.models import User


class Donation(models.Model):
    STATUS_CHOICES = [
        ('available', 'Available'),
        ('claimed', 'Claimed'),
        ('picked_up', 'Picked Up'),
    ]
    donor = models.ForeignKey(User, on_delete=models.CASCADE, related_name='donations')
    title = models.CharField(max_length=200)
    description = models.TextField()
    location = models.FloatField(null=True, blank=True)
    quantity = models.PositiveIntegerField()
    expiry = models.DateTimeField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='available')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title

class Claim(models.Model):
    donation = models.OneToOneField(Donation, on_delete=models.CASCADE, related_name='claim')
    claimant = models.ForeignKey(User, on_delete=models.CASCADE, related_name='claims')
    volunteer = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='volunteer_claims')
    claimed_at = models.DateTimeField(auto_now_add=True)
    pickup_tracked = models.BooleanField(default=False)
    pickup_time = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"Claim for {self.donation.title}"