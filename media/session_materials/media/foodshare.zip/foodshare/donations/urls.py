from django.urls import path

from .views import (
    claim_create,
    donation_create,
    donation_list,
    nearby_donations_json,
    track_pickup,
)

urlpatterns = [
    path('', donation_list, name='donation_list'),
    path('json/', nearby_donations_json, name='nearby_json'),
    path('create/', donation_create, name='donation_create'),
    path('claim/', claim_create, name='claim_create'),
    path('track/<int:pk>/', track_pickup, name='track_pickup'),
]