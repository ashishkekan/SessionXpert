from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.contrib.auth.decorators import login_required
from django.contrib.gis.db.models.functions import Distance
from django.contrib.gis.geos import Point
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render
from django.utils import timezone
from django.views.decorators.http import require_http_methods

from core.consumers import broadcast_donation_update

from .forms import ClaimForm, DonationForm
from .models import Claim, Donation


@login_required
def donation_list(request):
    qs = Donation.objects.filter(status='available').select_related('donor')
    user_loc = request.user.location
    if user_loc:
        qs = qs.filter(location__distance_lte=(user_loc, 50000)).annotate(distance=Distance('location', user_loc)).order_by('distance')
    return render(request, 'map.html', {'donations': qs})

@require_http_methods(["GET"])
def nearby_donations_json(request):
    qs = Donation.objects.filter(status='available').select_related('donor')
    user_loc = request.user.location
    if user_loc:
        qs = qs.filter(location__distance_lte=(user_loc, 50000)).annotate(distance=Distance('location', user_loc)).order_by('distance')
    data = [{
        'id': d.id,
        'title': d.title,
        'description': d.description,
        'status': d.status,
        'location': {'lat': d.location.y, 'lng': d.location.x},
        'distance': round(d.distance.m) if hasattr(d, 'distance') else None
    } for d in qs]
    return JsonResponse(data, safe=False)

@login_required
@require_http_methods(["POST"])
def donation_create(request):
    form = DonationForm(request.POST)
    if form.is_valid():
        donation = form.save(commit=False)
        donation.donor = request.user
        lat = float(request.POST.get('lat', 0))
        lng = float(request.POST.get('lng', 0))
        donation.location = Point(lng, lat, srid=4326)
        donation.save()
        channel_layer = get_channel_layer()
        async_to_sync(lambda: broadcast_donation_update(channel_layer, donation, f'New donation: {donation.title}'))()
        return JsonResponse({'success': True, 'id': donation.id})
    return JsonResponse({'errors': form.errors}, status=400)

@login_required
@require_http_methods(["POST"])
def claim_create(request):
    donation_id = request.POST.get('donation_id')
    donation = get_object_or_404(Donation, pk=donation_id)
    if donation.status == 'available' and not hasattr(donation, 'claim'):
        claim = Claim.objects.create(donation=donation, claimant=request.user)
        donation.status = 'claimed'
        donation.save()
        channel_layer = get_channel_layer()
        async_to_sync(lambda: broadcast_donation_update(channel_layer, donation, f'Donation {donation.title} claimed by {request.user.username}'))()
        return JsonResponse({'success': True})
    return JsonResponse({'error': 'Not available'}, status=400)

@login_required
@require_http_methods(["PATCH"])
def track_pickup(request, pk):
    claim = get_object_or_404(Claim, pk=pk)
    if claim.volunteer == request.user:
        claim.pickup_tracked = True
        claim.pickup_time = timezone.now()
        claim.donation.status = 'picked_up'
        claim.donation.save()
        claim.save()
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            f"user_{claim.donation.donor.id}",
            {
                'type': 'notification.message',
                'message': f'Your donation {claim.donation.title} has been picked up!'
            }
        )
        return JsonResponse({'status': 'Tracked'})
    return JsonResponse({'error': 'Unauthorized'}, status=403)