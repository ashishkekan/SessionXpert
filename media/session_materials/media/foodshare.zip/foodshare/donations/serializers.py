from rest_framework import serializers

from core.serializers import UserSerializer

from .models import Claim, Donation


class LocationField(serializers.Field):
    def to_representation(self, value):
        if value:
            return {'lat': value.y, 'lng': value.x}  # GeoDjango Point: (x=lng, y=lat)
        return None

    def to_internal_value(self, data):
        if data:
            return Point(data['lng'], data['lat'], srid=4326)
        return None

class DonationSerializer(serializers.ModelSerializer):
    donor = UserSerializer(read_only=True)
    location = LocationField()
    distance = serializers.SerializerMethodField()

    class Meta:
        model = Donation
        fields = '__all__'
        read_only_fields = ('id', 'donor', 'created_at', 'updated_at', 'distance')

    def get_distance(self, obj):
        # For nearby queries
        request = self.context.get('request')
        if request and request.user.location:
            from django.contrib.gis.geos import Distance
            distance = obj.location.distance(request.user.location)
            return round(distance.m)  # Meters
        return None

    def create(self, validated_data):
        validated_data['donor'] = self.context['request'].user
        return super().create(validated_data)

class ClaimSerializer(serializers.ModelSerializer):
    donation = serializers.PrimaryKeyRelatedField(queryset=Donation.objects.all())
    claimant = UserSerializer(read_only=True)

    class Meta:
        model = Claim
        fields = '__all__'
        read_only_fields = ('id', 'claimant', 'claimed_at')

    def create(self, validated_data):
        validated_data['claimant'] = self.context['request'].user
        claim = super().create(validated_data)
        # Update donation status
        claim.donation.status = 'claimed'
        claim.donation.save()
        return claim