from django import forms

from .models import Claim, Donation


class DonationForm(forms.ModelForm):
    class Meta:
        model = Donation
        fields = ['title', 'description', 'quantity', 'expiry']
        widgets = {
            'expiry': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        }

class ClaimForm(forms.ModelForm):
    class Meta:
        model = Claim
        fields = ['donation', 'volunteer']