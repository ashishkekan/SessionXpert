from django.contrib import admin

from .models import Message


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ('sender', 'donation', 'timestamp', 'content')
    list_filter = ('timestamp',)
    search_fields = ('content',)