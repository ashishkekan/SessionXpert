from django.urls import path

from .views import message_create, message_list

urlpatterns = [
    path('messages/', message_list, name='message_list'),
    path('messages/create/', message_create, name='message_create'),
    path('messages/<int:donation_id>/', lambda r, donation_id: message_list(r, donation_id), name='message_list_donation'),
]