from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.views.decorators.http import require_http_methods

from donations.models import Donation

from .forms import MessageForm
from .models import Message


@login_required
@require_http_methods(["GET"])
def message_list(request, donation_id=None):
    qs = Message.objects.select_related('sender', 'donation').order_by('timestamp')
    if donation_id:
        donation = get_object_or_404(Donation, pk=donation_id)
        if not (donation.donor == request.user or
                (getattr(donation, 'claim', None) and donation.claim and donation.claim.claimant == request.user) or
                (getattr(donation, 'claim', None) and donation.claim and donation.claim.volunteer == request.user)):
            return JsonResponse({'error': 'Unauthorized'}, status=403)
        qs = qs.filter(donation_id=donation_id)
    data = [{
        'id': m.id,
        'content': m.content,
        'sender': m.sender.username,
        'timestamp': m.timestamp.isoformat()
    } for m in qs]
    return JsonResponse(data, safe=False)

@login_required
@require_http_methods(["POST"])
def message_create(request):
    form = MessageForm(request.POST)
    if form.is_valid():
        donation_id = request.POST.get('donation_id')
        donation = get_object_or_404(Donation, pk=donation_id)
        if not (donation.donor == request.user or
                (getattr(donation, 'claim', None) and donation.claim and donation.claim.claimant == request.user) or
                (getattr(donation, 'claim', None) and donation.claim and donation.claim.volunteer == request.user)):
            return JsonResponse({'error': 'Unauthorized'}, status=403)
        message = form.save(commit=False)
        message.donation = donation
        message.sender = request.user
        message.save()
        return JsonResponse({'success': True, 'id': message.id})
    return JsonResponse({'errors': form.errors}, status=400)