// Shared map JS (include in templates)
function initMap() {
    map = L.map('map').setView([40.7128, -74.0060], 10);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
}

async function loadMarkers() {
    const response = await fetch('/donations/json/');
    const donations = await response.json();
    donations.forEach(d => {
        L.marker([d.location.lat, d.location.lng]).addTo(map)
            .bindPopup(`<b>${d.title}</b><br>${d.description}<br><button onclick="claimDonation(${d.id})">Claim</button><a href="/chat/messages/${d.id}/">Chat</a>`);
    });
}

async function claimDonation(id) {
    const formData = new FormData();
    formData.append('donation_id', id);
    formData.append('csrfmiddlewaretoken', getCookie('csrftoken'));
    const response = await fetch('/donations/claim/', {method: 'POST', body: formData});
    if (response.ok) {
        alert('Claimed!');
        loadMarkers();
    }
}