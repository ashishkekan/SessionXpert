let ws;

function connectNotifications() {
    ws = new WebSocket(`ws://${window.location.host}/ws/notifications/`);
    ws.onmessage = function(event) {
        const data = JSON.parse(event.data);
        if (data.type === 'notification') {
            alert(data.message);  // Or append to UI
        }
    };
}

function connectChat(donationId) {
    ws = new WebSocket(`ws://${window.location.host}/ws/chat/${donationId}/`);
    ws.onmessage = function(event) {
        const data = JSON.parse(event.data);
        document.getElementById('chat-messages').innerHTML += `<p><strong>${data.sender}:</strong> ${data.message}</p>`;
    };
}

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}