from django.urls import path

from .views import profile, register, user_data, user_login

urlpatterns = [
    path('register/', register, name='register'),
    path('login/', user_login, name='login'),
    path('profile/', profile, name='profile'),
    path('user-data/', user_data, name='user_data'),
]