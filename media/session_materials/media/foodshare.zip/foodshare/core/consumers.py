import json

from asgiref.sync import sync_to_async
from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncWebsocketConsumer
from django.contrib.gis.db.models.functions import Distance
from django.contrib.gis.geos import Point

from core.models import User
from donations.models import Donation


class NotificationConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope["user"]
        if self.user.is_anonymous:
            await self.close()
        else:
            await self.channel_layer.group_add(
                f"user_{self.user.id}",
                self.channel_name
            )
            await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(
            f"user_{self.user.id}",
            self.channel_name
        )

    async def receive(self, text_data):
        pass

    async def notification_message(self, event):
        await self.send(text_data=json.dumps({
            'type': 'notification',
            'message': event['message']
        }))

@database_sync_to_async
def get_nearby_groups(donation_location, radius=50000):
    users = User.objects.filter(
        location__distance_lte=(donation_location, radius),
        user_type__in=['recipient', 'volunteer']
    ).annotate(distance=Distance('location', donation_location))
    return [f"user_{u.id}" for u in users]

async def broadcast_donation_update(channel_layer, donation, message):
    groups = await get_nearby_groups(donation.location)
    for group in groups:
        await channel_layer.group_send(
            group,
            {
                'type': 'notification.message',
                'message': message
            }
        )